class APIError(Exception):
    pass


class NotFound(Exception):
    pass


class UserNotFound(Exception):
    pass

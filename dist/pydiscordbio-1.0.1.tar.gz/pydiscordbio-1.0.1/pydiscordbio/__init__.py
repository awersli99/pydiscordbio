from .client import Client
from .exceptions import *

__version__ = "1.0.1"
__author__ = "awersli99"
__license__ = "MIT"
